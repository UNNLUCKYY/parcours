Répertoire destiné à accueillir les fichiers de base de données H2.
